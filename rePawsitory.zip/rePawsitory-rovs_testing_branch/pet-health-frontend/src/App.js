import React from "react";
import PetHealthApp from "./pages/PetHealthApp";

function App() {
  return <PetHealthApp />;
}

export default App;
